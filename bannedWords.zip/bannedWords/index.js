module.exports = {
    Database: require('./database'),
    Config: require('./config'),
    Punishment: require('./punishments'),
    Matchings: require('./matching'),
}